package WorkShop;

/**
 *
 * @author s31011
 * @version 9/6/18
 */
public interface Tool {
    public String getName();
    public int getQuantity();
    public String getType();
    public void changer(int n);
}
